Put your charts here, it should look something like this:

assets/shared/data/your-song-name/
---- ./your-song-name-easy.json
---- ./your-song-name.json
---- ./your-song-name-hard.json
---- ./events.json
---- ./preload.json